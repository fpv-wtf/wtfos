#!/system/bin/sh
echo "wtfos: entware starting"

mount -o rw,remount /
mkdir -p /bin
ln -sf /system/bin/sh /bin/sh
if [[ ! -L /opt ]] ; then
    ln -sf /blackbox/wtfos/opt /opt
fi
mount -o ro,remount /
echo "wtfos: /opt and /bin/sh created"
