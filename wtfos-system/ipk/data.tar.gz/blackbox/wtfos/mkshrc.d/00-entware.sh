#!/system/bin/sh
#it's last because otherwise entware busybox overrides lots of important system stuff and breaks them
export PATH="$PATH:/opt/bin:/opt/sbin"
